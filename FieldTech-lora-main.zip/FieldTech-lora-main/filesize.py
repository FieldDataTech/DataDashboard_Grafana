import os
size = os.path.getsize("TroutC_35x35_2hrs.bmp")
print(f"File size: {size} bytes")