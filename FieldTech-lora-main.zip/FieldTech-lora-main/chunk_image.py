from pathlib import Path
from typing import Union
from assemble_images import assemble_picture, write_images_to_files


def read_binary_file_as_chunks(filepath: Union[str, Path], chunk_size: int = 32) -> list:
    """Read a binary file and return a list of chunks (each a bytearray).
    
    Args:
        filepath: Path to the binary file
        chunk_size: Size of each chunk in bytes (default 32)
    
    Returns:
        List of bytearrays, each containing chunk_size bytes (last chunk may be smaller)
    """
    filepath = Path(filepath)
    chunks = []
    header = []
    
    header_size = 54  # Typical BMP header size
    with open(filepath, "rb") as f:
        # header.append(bytearray(f.read(header_size)))
        while True:
            if len(header) < 1:
                h = f.read(header_size)
                if not h:
                    break
                header.append(bytearray(h))

            chunk = f.read(chunk_size)
            if not chunk:
                break
            chunks.append(bytearray(chunk))
    
    return chunks

if __name__ == "__main__":
    file_path = "./TroutC_35x35_2hrs.bmp"
    chunk_size = 32
    chunks = read_binary_file_as_chunks(file_path, chunk_size)
    for i, chunk in enumerate(chunks):
        print(f"Chunk {i}: {chunk}")
        #     slice_id = f"{year}{str(month).zfill(2)}{str(day).zfill(2)}_{str((hour//2)*2).zfill(2)}"
        assemble_picture("tenant_name1", "application_name1", "dev_eui1", "20251124_0100", i, chunk)

    write_images_to_files();