import psycopg2
from datetime import datetime, timedelta, timezone
from payload_decode import decode_payload
from assemble_images import assemble_picture, write_images_to_files   


def fetch_and_update():
    conn = connect_to_db()
    cur = conn.cursor()
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
    print("Fetching records with time > ", yesterday)
    query = "SELECT deduplication_id, tenant_name, application_name, dev_eui, data FROM event_up WHERE time > %s and slice_id is NULL;"
    cur.execute(query, (yesterday,))
    rows = cur.fetchall()
    for deduplication_id, tenant_name, application_name, dev_eui, data_bytes in rows:
        decoded = decode_payload(bytearray(data_bytes))
        update_query = """
            UPDATE event_up
            SET format=%s, year=%s, month=%s, day=%s, hour=%s, minute=%s,
                deployment_number=%s, latitude=%s, longitude=%s, temperature=%s,
                ambient_light=%s, motion_0_9=%s, motion_10_19=%s, motion_20_29=%s,
                motion_30_39=%s, motion_40_49=%s, motion_50_59=%s, slice_id=%s,
                slice_number=%s, picture_slice=%s, crc=%s, dev_time=%s
            WHERE deduplication_id=%s
        """
        # todo: temperature, for now it is an int
        # create dev_time from year, month, day, hour, minute
        dev_time = datetime(decoded["year"], decoded["month"], decoded["day"],
                            decoded["hour"], decoded["minute"], tzinfo=timezone.utc)
        any_motion = (decoded["motion_0_9"] + decoded["motion_10_19"] +
                      decoded["motion_20_29"] + decoded["motion_30_39"] +
                      decoded["motion_40_49"] + decoded["motion_50_59"]) > 0;
        cur.execute(update_query, (
            decoded["format"], decoded["year"], decoded["month"], decoded["day"],
            decoded["hour"], decoded["minute"], decoded["deployment_number"],
            decoded["latitude"], decoded["longitude"], int(decoded["temperature"]),
            decoded["ambient_light"], decoded["motion_0_9"], decoded["motion_10_19"],
            decoded["motion_20_29"], decoded["motion_30_39"], decoded["motion_40_49"],
            decoded["motion_50_59"], decoded["slice_id"], decoded["slice_number"],
            decoded["slice_of_picture"], decoded["crc"], dev_time, any_motion,
            deduplication_id
        ))
        print(f"Updated row {deduplication_id}")
        # image_name is the slice_id
        assemble_picture(tenant_name, application_name, dev_eui, decoded("slice_id"), decoded("slice_number"), decoded("slice_of_picture"))

    write_images_to_files();
    conn.commit()
    cur.close()
    conn.close()

def connect_to_db():
    conn = psycopg2.connect(
        dbname="chirpstack_integration",
        user="chirpstack_integration",
        password="chirpstack_integration",
        host="localhost",
        port=5433
    )

    return conn

if __name__ == "__main__":
    fetch_and_update()