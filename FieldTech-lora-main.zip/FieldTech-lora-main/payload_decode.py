
import base64
import sys


def get_bits(bytearray, byte_index, bit_index, length):
    value = 0
    mask = ((1 << length) - 1) << (bit_index + 1 - length)
    shift = bit_index + 1 - length
    value = (bytearray[byte_index] & mask) >> (shift)

    #
    # Print mask in hex and shift in hex for codec javascript
    # print("byte_index", byte_index, "mask", hex(mask), " shift: ", hex(bit_index + 1 - length))
    # if shift > 0:
    #     print(f"bytearray[{byte_index}] & {hex(mask)} >> {hex(shift)}")
    # else:
    #     print(f"bytearray[{byte_index}] & {hex(mask)}")
    
    return value



def decode_payload(bytearray):
    # 0, 7, 4 format
    format = get_bits(bytearray, 0, 7, 4)
    #print("format: ", format)
    # 0, 3, 4 year
    year = get_bits(bytearray, 0, 3, 4) + 2020
    #print("year: ", year)
    # 1, 7, 4 month
    month = get_bits(bytearray, 1, 7, 4)
    #print("month: ", month)
    # 1, 3, 4 + 2, 7, 1 day
    day = get_bits(bytearray, 1, 3, 4) * 2 + get_bits(bytearray, 2, 7, 1)
    #print("day: ", day)
    # 2, 6, 5 hour
    hour = get_bits(bytearray, 2, 6, 5)
    #print("hour: ", hour)
    # 2, 1, 2 + 3, 7, 4 minute
    minute = get_bits(bytearray, 2, 1, 2) * 16 + get_bits(bytearray, 3, 7, 4)
    #print("minute: ", minute)
    # 3, 3, 4 + 4, 7, 8 deployment_number
    deployment_number = get_bits(bytearray, 3, 3, 4) * 256 + get_bits(bytearray, 4, 7, 8)
    #print("deployment_number: ", deployment_number)
    # 5, 6, 1 latitude_sign
    latitude_sign = get_bits(bytearray, 5, 6, 1)
    #print("latitude_sign: ", latitude_sign)
    # 5, 5, 6 + 6, 7, 1 latitude_whole
    latitude_whole = get_bits(bytearray, 5, 5, 6) * 2 + get_bits(bytearray, 6, 7, 1)
    #print("latitude_whole: ", latitude_whole)
    # 6, 6, 7 + 7, 7, 8 + 8, 7, 2 latitude_fraction
    latitude_fraction = get_bits(bytearray, 6, 6, 7) * 512 + get_bits(bytearray, 7, 7, 8) * 4 + get_bits(bytearray, 8, 7, 2)
    #print("latitude_fraction: ", latitude_fraction)
    latitude = latitude_whole + latitude_fraction / 1000.0
    if latitude_sign == 1:
        latitude = -latitude
    #print("latitude: ", latitude)
    # 8, 5, 1 longitude_sign
    longitude_sign = get_bits(bytearray, 8, 5, 1)
    #print("longitude_sign: ", longitude_sign)
    # 8, 4, 5 + 9, 7, 3 longitude_whole
    longitude_whole = get_bits(bytearray, 8, 4, 5) * 8 + get_bits(bytearray, 9, 7, 3)
    #print("longitude_whole: ", longitude_whole)
    # 9, 4, 5 + 10, 7, 8 + 11, 7, 4 longitude_fraction
    longitude_fraction = get_bits(bytearray, 9, 4, 5) * 2048 + get_bits(bytearray, 10, 7, 8) * 16 + get_bits(bytearray, 11, 7, 4)
    #print("longitude_fraction: ", longitude_fraction)
    longitude = longitude_whole + longitude_fraction / 1000.0
    if longitude_sign == 1:
        longitude = -longitude
    #print("longitude: ", longitude)
    # 11, 3, 4 + 12, 7, 8 temperature
    temperature = get_bits(bytearray, 11, 3, 4) * 256 + get_bits(bytearray, 12, 7, 8)
    if temperature >= 2048:
        temperature -= 4096
    temperature = temperature / 10.0
    #print("temperature: ", temperature)
    # 13, 7, 8 ambient_light
    ambient_light = get_bits(bytearray, 13, 7, 8)
    #print("ambient_light: ", ambient_light)
    # 14, 7, 4 motion_0_9
    motion_0_9 = get_bits(bytearray, 14, 7, 4)
    #print("motion_0_9: ", motion_0_9)
    # 14, 3, 4 motion_10_19
    motion_10_19 = get_bits(bytearray, 14, 3, 4)
    #print("motion_10_19: ", motion_10_19)
    # 15, 7, 4 motion_20_29
    motion_20_29 = get_bits(bytearray, 15, 7, 4)
    #print("motion_20_29: ", motion_20_29)
    # 15, 3, 4 motion_30_39
    motion_30_39 = get_bits(bytearray, 15, 3, 4)
    #print("motion_30_39: ", motion_30_39)
    # 16, 7, 4 motion_40_49
    motion_40_49 = get_bits(bytearray, 16, 7, 4)
    #print("motion_40_49: ", motion_40_49)
    # 16, 3, 4 motion_50_59
    motion_50_59 = get_bits(bytearray, 16, 3, 4)
    #print("motion_50_59: ", motion_50_59)

    slice_number = 60 * (hour % 2) + minute

    # slice 117 is repeat of 0
    # if slice_number == 117:
    #     slice_number = 0
    # # slice 118 is repeat of 1
    # if slice_number == 118:
    #     slice_number = 1
    # slice 119 is repeat of 2
    if slice_number == 119:
        slice_number = 2

    #print("slice_number: ", slice_number)

    slice_id = f"{year}{str(month).zfill(2)}{str(day).zfill(2)}_{str((hour//2)*2).zfill(2)}"
    #print("slice_id: ", slice_id)
    # 17..48 slice_of_picture
    slice_of_picture = bytearray[17:49]
    #print("slice_of_picture: ", slice_of_picture.hex())
    # 49-50 crc
    crc = get_bits(bytearray, 49, 7, 8) * 256 + get_bits(bytearray, 50, 7, 8)
    #print("crc: ", crc)

    return {
        "format": format,
        "year": year,
        "month": month,
        "day": day,
        "hour": hour,
        "minute": minute,
        "deployment_number": deployment_number,
        "latitude": latitude,
        "longitude": longitude,
        "temperature": temperature,
        "ambient_light": ambient_light,
        "motion_0_9": motion_0_9,
        "motion_10_19": motion_10_19,
        "motion_20_29": motion_20_29,
        "motion_30_39": motion_30_39,
        "motion_40_49": motion_40_49,
        "motion_50_59": motion_50_59,
        "slice_number": slice_number,
        "slice_id": slice_id,  # Image identifier
        "slice_of_picture": slice_of_picture,
        "crc": crc
    }

if __name__ == "__main__":
    coded_string=sys.argv[1]
    bytearray=base64.b64decode(coded_string)
    print(bytearray.hex())
    decode_payload(bytearray)

