# Image-Slice-Assembler

This is single manual run taking all unprocessed data from yesterday and creating images

The images are written to:
  - for Macos
      - `"/opt/homebrew/opt/grafana/share/grafana/public/img/" + "loRaWAN/"`
  - for Linux
      - `"/usr/share/grafana/public/img/" + "loRaWAN/"`

## Example run with full path to add to cron tab 
` /usr/bin/python3 /Users/rtekal/Documents/repos/FieldTech-lora/retrieve_event_up.py`

## Example run within this directory
`python3 ./retrieve_event_up.py`
