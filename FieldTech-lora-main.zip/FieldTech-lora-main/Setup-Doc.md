# Setup Documentation
## Install OS
  [Follow document to install Debian OS](Install-Debian.md)
## Install Chirpstack
  Follow the instructions from 
  - https://www.chirpstack.io/docs/getting-started/debian-ubuntu.html
     
  Install Packages ...etc
```
    sudo apt install \
      mosquitto \
      mosquitto-clients \
      redis-server \
      redis-tools \
      postgresql
```

## Setup Integration Database
  Follow the instructions from
  - https://www.chirpstack.io/docs/chirpstack/integrations/postgresql.html

## Additional Integration Database Changes
Lorawan conveys very tiny packets of data every minute from each camera.
It will take a minimum of 2 hours to as much as 12 hours to send one complete image from each camera.

An external python program runs periodically (every two hours) and processes these tiny data packets stored
in the Postgres integration database and assembles the packets into a bit map file.

These columns are added to allow easy communication of data into Grafana visualization tool.
If you do not intend to visualize the data in Grafana, some of these columns are not used.

## Initialize Database for image slices
Add these columns to the `event_up` table in the `chirpstack_integration` database, use the following SQL statement in `psql`:

````sql
ALTER TABLE event_up
ADD COLUMN format integer,
ADD COLUMN year integer,
ADD COLUMN month integer,
ADD COLUMN day integer,
ADD COLUMN hour integer,
ADD COLUMN minute integer,
ADD COLUMN deployment_number integer,
ADD COLUMN latitude double precision,
ADD COLUMN longitude double precision,
ADD COLUMN temperature integer,
ADD COLUMN ambient_light integer,
ADD COLUMN motion_0_9 integer,
ADD COLUMN motion_10_19 integer,
ADD COLUMN motion_20_29 integer,
ADD COLUMN motion_30_39 integer,
ADD COLUMN motion_40_49 integer,
ADD COLUMN motion_50_59 integer,
ADD COLUMN picture_slice bytea,
ADD COLUMN slice_number integer,
ADD COLUMN slice_id character(16);
````

After the above ALTER is done, the table should look like this:
```
/ # psql -U chirpstack_integration -d chirpstack_integration
psql (14.17)
Type "help" for help.

chirpstack_integration=> \d+ event_up;
                                                        Table "public.event_up"
       Column        |           Type           | Collation | Nullable | Default | Storage  | Compression | Stats target | Description 
---------------------+--------------------------+-----------+----------+---------+----------+-------------+--------------+-------------
 deduplication_id    | uuid                     |           | not null |         | plain    |             |              | 
 time                | timestamp with time zone |           | not null |         | plain    |             |              | 
 tenant_id           | uuid                     |           | not null |         | plain    |             |              | 
 tenant_name         | text                     |           | not null |         | extended |             |              | 
 application_id      | uuid                     |           | not null |         | plain    |             |              | 
 application_name    | text                     |           | not null |         | extended |             |              | 
 device_profile_id   | uuid                     |           | not null |         | plain    |             |              | 
 device_profile_name | text                     |           | not null |         | extended |             |              | 
 device_name         | text                     |           | not null |         | extended |             |              | 
 dev_eui             | character(16)            |           | not null |         | extended |             |              | 
 tags                | jsonb                    |           | not null |         | extended |             |              | 
 dev_addr            | character(8)             |           | not null |         | extended |             |              | 
 adr                 | boolean                  |           | not null |         | plain    |             |              | 
 dr                  | smallint                 |           | not null |         | plain    |             |              | 
 f_cnt               | bigint                   |           | not null |         | plain    |             |              | 
 f_port              | smallint                 |           | not null |         | plain    |             |              | 
 confirmed           | boolean                  |           | not null |         | plain    |             |              | 
 data                | bytea                    |           | not null |         | extended |             |              | 
 object              | jsonb                    |           | not null |         | extended |             |              | 
 rx_info             | jsonb                    |           | not null |         | extended |             |              | 
 tx_info             | jsonb                    |           | not null |         | extended |             |              | 
 format              | integer                  |           |          |         | plain    |             |              | 
 year                | integer                  |           |          |         | plain    |             |              | 
 month               | integer                  |           |          |         | plain    |             |              | 
 day                 | integer                  |           |          |         | plain    |             |              | 
 hour                | integer                  |           |          |         | plain    |             |              | 
 minute              | integer                  |           |          |         | plain    |             |              | 
 deployment_number   | integer                  |           |          |         | plain    |             |              | 
 latitude            | double precision         |           |          |         | plain    |             |              | 
 longitude           | double precision         |           |          |         | plain    |             |              | 
 temperature         | integer                  |           |          |         | plain    |             |              | 
 ambient_light       | integer                  |           |          |         | plain    |             |              | 
 motion_0_9          | integer                  |           |          |         | plain    |             |              | 
 motion_10_19        | integer                  |           |          |         | plain    |             |              | 
 motion_20_29        | integer                  |           |          |         | plain    |             |              | 
 motion_30_39        | integer                  |           |          |         | plain    |             |              | 
 motion_40_49        | integer                  |           |          |         | plain    |             |              | 
 motion_50_59        | integer                  |           |          |         | plain    |             |              | 
 picture_slice       | bytea                    |           |          |         | extended |             |              | 
 slice_number        | integer                  |           |          |         | plain    |             |              | 
 slice_id            | character(16)            |           |          |         | extended |             |              | 
Indexes:
    "event_up_pkey" PRIMARY KEY, btree (deduplication_id)
Access method: heap
```


## Install Image-Slice-Assembler

Set up a cron schedule as follows
```
EDITOR=nano crontab -e
```

Insert the following line and save (change yourusername).
The program will run every two hours
```
0 */2 * * * /usr/bin/python3 /Users/yourusername/Documents/scripts/retrieve_event_up.py >> /Users/yourusername/Documents/scripts/cron_log.txt 2>&1
```
