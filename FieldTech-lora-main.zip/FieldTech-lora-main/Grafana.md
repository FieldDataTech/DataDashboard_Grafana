# Grafana

## Installation

- To install Grafana on Mac, issue the following commands
```
brew update
brew install grafana

brew services start grafana
```
Details are mentioned at: https://grafana.com/docs/grafana/latest/setup-grafana/installation/mac/

- To install Grafana on Debian, install the Grafana OSS stable version,
the details are mentioned at: https://grafana.com/docs/grafana/latest/setup-grafana/installation/debian/

## Setting up Grafana for Field Data Tech
The follow instructions help setup the Grafana Dashboard for the Field Data Tech

### Define the Data Source 
This step is only needed once.

- Open Grafana in your web browser at `http://localhost:3000/` (default port is 3000).
- Log in with the default username and password (admin/admin).
- Navigate to "Configuration" > "Data Sources".
- Click on "Add data source" and select "PostgreSQL".


The following is how the datasource configuration should look:
![Grafana PostgreSQL Datasource](./GrafanaDataSource.png)

### Deploying the Dashboard
This step is only needed once.

- Go to Home -> Dashboards
- Click New
- Select 'Import'
- Drag and Drop 'FieldDataTech-Dashboard.json'

### Usage of the Dashboard
- Click the 'Field Data Tech Dashboard' from the Dashboards
- Select the proper time range
- There will be four drop downs:
  - First select the required Tenant from the 'Tenant' drop down
  - Next select the Application
    - Only Applications pertaining to the selected Tenant will be populated in the drop down
  - Next select the Device-Name
    - Only devices within the selected Tenant and Application will appear in the Device-Name drop down
    - The corresponding Device_EUI will be shown

- Data should be visible as shown in the following image

![Sample Grafana Dashboard](./SampleGrafanaDashboard.png)

#### Todo:
- Change the time scale of the graph to use the device time (not the server time)
- Show the captured image instead of the 'Image ID'


