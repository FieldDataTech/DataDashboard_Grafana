
# Install Debian (From Google Search)

## Step 1: Prepare Your Installation Media
1. Download Debian: Go to the Debian website (debian.org) and download the appropriate installation image (e.g., a small network install ISO) for your laptop's architecture (usually AMD64).
2. Get a USB Tool: Download Rufus (for Windows) or Balena Etcher (for Windows, macOS, Linux).
3. Create Bootable USB: Use your tool to write the downloaded Debian ISO file to a USB flash drive (8GB or larger), ensuring it's set to write in ISO Image mode. 

## Step 2: Configure Your Laptop to Boot from USB
1. Insert USB: Plug the bootable USB into your laptop.
2. Access Boot Menu/BIOS: Restart your laptop and repeatedly press the key for the Boot Menu (often F12, F10, Esc, Del, or F2, varies by manufacturer).
3. Select USB: Choose your USB drive from the boot menu to start the Debian installer. 

## Step 3: Run the Debian Installer 
1. Graphical Install: Select the "Graphical install" option from the initial Debian menu.
2. Language & Location: Choose your language, location, and keyboard layout.
3. Network & Hostname: Connect to the internet (if using netinstall), set a hostname (e.g., "MyDebian"), and skip the domain name if you're on a home network.
4. User Setup: Set a strong password for the root user (or leave blank to use sudo) and create your regular user account with a full name and password.
5. Disk Partitioning: For beginners, select "Guided - use entire disk" and accept the default single partition scheme, which will erase all data on the chosen drive.
6. Software Selection: Choose a desktop environment like Cinnamon, GNOME, or KDE, and select standard system utilities.
7. Install GRUB: Install the GRUB boot loader to the main hard drive (e.g., /dev/sda) when prompted. 

## Step 4: Finish Up
1. Reboot: Remove the USB drive and reboot your laptop.
2. Log In: Log in with your new username and password to start using Debian. 