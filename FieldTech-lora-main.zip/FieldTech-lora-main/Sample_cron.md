# Sample Cron Tab
- Runs every 2 hours

```
0 */2 * * * /usr/bin/python3 /Users/rtekal/Documents/repos/FieldTech-lora/retrieve_event_up.py >> /Users/rtekal/Documents/cron_log.txt 2>&1
```


