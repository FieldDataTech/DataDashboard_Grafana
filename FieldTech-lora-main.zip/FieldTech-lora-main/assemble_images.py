import os
import sys
from pathlib import Path
from typing import Union, Optional


# 35x35 bmp image header
BMP_HEADER_35x35 = bytearray.fromhex(
    "42 4D FA 0E 00 00 00 00 00 00 36 00 00 00 28 00"
    "00 00 23 00 00 00 23 00 00 00 01 00 18 00 00 00"
    "00 00 C4 0E 00 00 D3 35 00 00 D3 35 00 00 00 00"
    "00 00 00 00 00 00")

BMP_HEADER_SIZE = len(BMP_HEADER_35x35)

SLICE_BYTES_35_35 = 32

BLANK_SLICE_35_35 = bytearray([0xFF] * SLICE_BYTES_35_35)  

if sys.platform.startswith('darwin'):
    # for Macos
    BASE_DIR = "/opt/homebrew/opt/grafana/share/grafana/public/img/" + "loRaWAN/"
elif sys.platform.startswith('linux'):
    # for Linux
    BASE_DIR = "/usr/share/grafana/public/img/" + "loRaWAN/"
else:
    # default to current directory
    BASE_DIR = "./loRaWAN/"

MAX_SLICE_35_35 = 119 

working_images = {}

def make_image_entity(fn: str, header: Optional[Union[bytes, bytearray]] = BMP_HEADER_35x35, image: Optional[Union[bytes, bytearray]] = None, size: int = MAX_SLICE_35_35):
    """Return a dict keyed by `fn` with three items:

    { fn: {
        'header': bytearray,        # binary header bytes
        'image': bytearray,         # bytearrays for image (slices)
        'slice_log': [int,...]      # list of `size` integers (e.g., slice metadata)
      }
    }

    Args:
        fn: filename/key for the dict
        header: bytes or bytearray containing the file header
        size: number of slices to pre-create for the image and slice_log
    """
    global working_images

    hdr = bytearray(header)
    if image is None:
        image_slices = bytearray(BLANK_SLICE_35_35 * size)
    else:
        image_slices = bytearray(image)
    slice_log = [0 for _ in range(size)]
    working_images[fn] = {"header": hdr, "image": image_slices, "slice_log": slice_log}




def initialize_working_images(image_path: Path, image_name: str):

    # Note: Ensure the directory exists, so while writing the file later, it works.
    image_path.mkdir(parents=True, exist_ok=True)

    image_path_file = image_path / image_name
    if not image_path_file.exists():
        # Note: Postpone create of the file while writing.
        make_image_entity(image_path_file, BMP_HEADER_35x35, None, MAX_SLICE_35_35)
    else:
        try:
            with open(image_path_file, "rb") as f:
                bmp_data = bytearray(f.read())
                hdr = bmp_data[:BMP_HEADER_SIZE]

                # remove header
                image_data = bmp_data[len(BMP_HEADER_35x35):]
                make_image_entity(image_path_file, hdr, image_data, MAX_SLICE_35_35)
    
        except Exception as e:
            print(f"Error loading existing image {image_path_file}: {e}")

        # ignore the error while reading slice log
        with open(str(image_path_file)+".log", "r") as f:
            slice_log_data = f.read()
            for idx, count in enumerate(slice_log_data):
                working_images[image_path_file]["slice_log"][idx] = int(count)


def assemble_picture(tenant_name, application_name, dev_eui, slice_id, slice_number, slice_of_picture):
    """Assemble a picture from its slices.
        Example 
          slice_id: '20240101_00'
          slice_number: 0 to 119
          slice_of_picture: bytearray of slice data
  
    """
    global working_images

    if slice_number > MAX_SLICE_35_35:
        print(f"Slice number {slice_number} exceeds maximum {MAX_SLICE_35_35}. Ignoring slice.")
        return
    if len(slice_of_picture) > SLICE_BYTES_35_35:
        print(f"Slice size {len(slice_of_picture)} does not match expected {SLICE_BYTES_35_35}. Ignoring slice.")
        return
    
    base = Path(BASE_DIR).expanduser()
    image_path = base / tenant_name / application_name / dev_eui 
    image_name = f"{slice_id}.bmp"
    image_file = image_path / image_name

    bmp = working_images.get(image_file)
    if bmp is None:
        initialize_working_images(image_path, image_name)

    offset = slice_number * SLICE_BYTES_35_35
    working_images[image_file]["image"][offset:offset+SLICE_BYTES_35_35] = slice_of_picture
    working_images[image_file]["slice_log"][slice_number] += 1



def write_images_to_files():
    """Write all images in working_images to disk.
    
    For each image, writes the header followed by all received slices
    (marked with slice_log == 1) to a .bmp file.
    """
    global working_images
    for filename, image_data in working_images.items():
        header = image_data["header"]
        image = image_data["image"]
        slice_log = image_data["slice_log"]
        
        # Note: While initializing the image, the path has been created.

        # Write header and all received slices to file
        with open(filename, "wb") as f:
            f.write(header)
            f.write(image)

        with open(str(filename)+".log", "w") as f:
            for idx, slice_count in enumerate(slice_log):
                if slice_count == 0:
                    print(f"No slice received for {idx}")
                elif slice_count == 1:
                        pass # good
                else:
                    print(f"Multiple slices {slice_count} received for {idx}")
                f.write(str(slice_count))

        print(f"Wrote image file: {filename} and slice log file: {filename}.log")

    # clear out working images after writing
    working_images = {}
